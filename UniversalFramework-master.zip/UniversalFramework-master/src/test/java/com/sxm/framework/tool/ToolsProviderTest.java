package com.sxm.framework.tool;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import com.sxm.framework.tool.ToolProvider;
import com.sxm.framework.tool.Tools;
import com.sxm.framework.tool.impl.ToolProviderImpl;

public class ToolsProviderTest {
 
  
  @Test
  public void testDrivers() {

  }
}
