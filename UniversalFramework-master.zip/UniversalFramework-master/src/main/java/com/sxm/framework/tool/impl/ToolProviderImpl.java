package com.sxm.framework.tool.impl;

import org.openqa.selenium.WebDriver;

import com.sxm.framework.common.AppiumDriverUtil;
import com.sxm.framework.common.SeleniumDriverUtil;
import com.sxm.framework.exception.InValidOSException;
import com.sxm.framework.exception.InValidToolException;
import com.sxm.framework.tool.ToolProvider;
import com.sxm.framework.tool.Tools;

/**
 * Central Class to return the Driver based on Tool and OS To be used by All
 * projects web,Android,IOS
 * 
 * @author subramanyamp
 *
 */
public class ToolProviderImpl implements ToolProvider {

    private static ToolProviderImpl provider = null;
    private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
    private AppiumDriverUtil appiumutil = new AppiumDriverUtil();

    public static ToolProviderImpl getInstance() {
        if (provider == null) {
            provider = new ToolProviderImpl();
        }
        return provider;
    }
    
    private ToolProviderImpl() {
        
        
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sxm.framework.tool.ToolProvider#getTools(com.sxm.framework.tool.Tools
     * .SupportedTools, java.lang.String)
     */
    public WebDriver getToolsDriver(Tools.SupportedTools cName, String os)
            throws InValidOSException, InValidToolException {

        if (cName.toString().equalsIgnoreCase("selenium")) {

            return selenium.getDriver();

        } else if (cName.toString().equalsIgnoreCase("APPIUM")) {

            if (os.equalsIgnoreCase("Android")) {

                return appiumutil.getAndroidDriver();

            } else if (os.equalsIgnoreCase("IOS")) {
                // TODO implement IOS Driver and change
                return appiumutil.getIOSDriver();

            } else {
                throw new InValidOSException(" In Valid OS Excception");
            }
        } else {
            throw new InValidToolException(" In Valid Tool Excception");
        }
    }

    public static void main(String[] args) {

        ToolProvider provider = null;
        try {
            provider = new ToolProviderImpl();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        try {
            WebDriver driver = provider.getToolsDriver(
                    Tools.SupportedTools.SELENIUM, "WEB");

            WebDriver mobiledriver = provider.getToolsDriver(
                    Tools.SupportedTools.APPIUM, "android");

        } catch (InValidOSException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InValidToolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}