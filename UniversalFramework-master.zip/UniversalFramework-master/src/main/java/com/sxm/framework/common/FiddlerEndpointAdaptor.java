package com.sxm.framework.common;

public class FiddlerEndpointAdaptor {
	
	
	

}
