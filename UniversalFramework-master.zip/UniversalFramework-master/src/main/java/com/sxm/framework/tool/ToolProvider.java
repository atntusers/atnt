package com.sxm.framework.tool;

import org.openqa.selenium.WebDriver;

import com.sxm.framework.exception.InValidOSException;
import com.sxm.framework.exception.InValidToolException;

public interface ToolProvider {
	
	/**
	 * Method to be called by all projects to their driver based on Tool and OS
	 * 
	 * @param cName
	 * @param os
	 * @return
	 * @throws InValidOSException
	 * @throws InValidToolException
	 */
	public WebDriver getToolsDriver( Tools.SupportedTools cName, String os) throws InValidOSException, InValidToolException;
}