package com.sxm.framework.base;

import com.sxm.framework.common.SeleniumDriverUtil;
import com.sxm.framework.common.ExcelUtil;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class WebTestCase {

    private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	protected WebDriver driver = selenium.getDriver();
	
	private ExcelUtil ds;
	private WritableWorkbook workbook;

	public WebTestCase() {
	/*	login = new Login();
		home = new Home();*/

		String filepath = "src/test/resources/Report.xls";
		filepath = System.getProperty("user.dir") + "/" + filepath;
		File file = new File(filepath);
		WorkbookSettings wbSettings = new WorkbookSettings();

		wbSettings.setLocale(new Locale("en", "EN"));

		try {
			workbook = Workbook.createWorkbook(file, wbSettings);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		workbook.createSheet("Report", 0);
		try {
			workbook.write();
			workbook.close();
			Reporter.log("Sheet created", true);
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ds = new ExcelUtil();
	}

	/**
	 * Before suite annotation contains the code related to application login
	 * with valid credentials
	 */
	@BeforeSuite(alwaysRun = true)
	public void loginToApp() {
		driver.manage().deleteAllCookies();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().window().maximize();
		driver.get(SeleniumDriverUtil.getLoginURL());
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		//login.loginToApp(Configuration.getUserName(),
		//		Configuration.getPassword());
	}

	/**
	 * @AfterMethod annotation contains the code related to application to
	 *              navigate to home page irrespective or pass or fail of test
	 *              case
	 */
	@AfterMethod(alwaysRun = true)
	public void closeMenu() {
		//home.closeMenu();
	}

	/**
	 * @AfterSuite annotation contains the code related to application to close
	 *             the browser after all test cases are executed
	 */
	@AfterSuite(alwaysRun = true)
	public void closeBrowser() {
		ds.closeFile();
		driver.manage().deleteAllCookies();
		driver.quit();
	}
}