package com.sxm.framework.base;

import io.appium.java_client.android.AndroidDriver;
import jxl.Workbook;
import jxl.write.WritableWorkbook;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

/*import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Channels;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.CommonCode;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Configuration;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Home;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Logfiledata;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Login;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Me;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.ReadExcel;
import com.siriusxm.BIautomation.SiriusXMAndroidAutomation.Search;*/

public class MobileTestCase {
	
/*	public AndroidDriver driver = Configuration.app();
	public CommonCode common;

	public ReadExcel read;
	public Login login;

	public Me me;
	public Channels channel;
	public Home home;
	public Logfiledata file;
	public Search search;

	static Workbook wbook;
	static WritableWorkbook wwbCopy;
	static String ExecutedTestCasesSheet;
	WritableWorkbook workbook;

	public TestngAnnotationsTest() {

		common = new CommonCode();
		me = new Me();
		read = new ReadExcel();
		login = new Login();
		home = new Home();
		channel = new Channels();
		home = new Home();
		search = new Search();
		file = new Logfiledata();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		try {
			Thread.sleep(12000);
			driver.findElement(By.id("com.sirius:id/login")).click();
		} catch (Exception e) {

		}
		driver.findElement(By.id("com.sirius:id/screenName"))
				.sendKeys("k20FEi");
		driver.findElement(By.id("com.sirius:id/password"))
				.sendKeys("0srQuiU0");
		driver.findElement(By.id("com.sirius:id/authenticateUser")).click();
		try {
			Thread.sleep(18000);
		} catch (Exception e) {

		}

	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod() {
		file.deletefilesfrommobile();
		driver.resetApp();
	}
*/

}
