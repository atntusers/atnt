package com.sxm.framework.exception;

public class InValidToolException extends Exception {

	private static final long serialVersionUID = 1L;

	public InValidToolException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InValidToolException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}