package com.att.functional.regression;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import com.att.framework.CommonFunctions;
import com.att.framework.Driver;
import com.att.framework.Reporting;
import com.att.framework.Driver.HashMapNew;
import com.att.hrock.AccountOverviewPage;
import com.att.hrock.CheckAvailabilityPage;
import com.att.hrock.GlobalNavMenu;
import com.att.hrock.LoginFromOlamHardrock;
import com.att.hrock.LoginPage;
import com.att.hrock.ShopLandingPage;
import com.att.wbfc.*;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class WBFCModifyFlows {


	HashMap <String, String> Environment = new HashMap<String, String>();
	HashMapNew Dictionary = new HashMapNew();
	Reporting Reporter;

	//Instances
	Driver d;
	WebDriver driver;
	String driverType;
	CommonFunctions objCommon;
	Object testId;
	boolean bSkip;
	int TestCounter =0;
	ITestResult result;
	String env;
	String runOnEnv;
	String browser;

	//private Logger logger = Logger.getLogger(getClass().getName());
	//private String browserFlavor;

	@Parameters({"browser", "envcode","session_name"})
	@BeforeClass
	public void beforeClass(@Optional("") String browser, @Optional("") String runOnEnv,@Optional("") String sessionName) {
		try{
			driverType = browser;
			Environment.put("CLASS_NAME", this.getClass().getSimpleName());
			d = new Driver(driverType, Dictionary, Environment);
			env = System.getProperty("envName");	
			if (env==null) 
			{
				env = runOnEnv;
			}
			Assert.assertNotNull(env);
			//Add env global environments
			Environment.put("ENV_CODE", env);

			// Get the skiped cells
			d.getSkipedCells();
			d.fetchEnvironmentDetails(); //from Environment.xlsx
			d.createExecutionFolders(Environment.get("CLASS_NAME"));	
			Reporter = new Reporting(driver, driverType, Dictionary, Environment);
			Reporter.fnCreateSummaryReport();
			//objCommon = new CommonFunctions(driver, driverType, Environment, Reporter);


			if(Environment.get("UNIX_LOG_VALIDATION").toLowerCase().equals("yes") && driverType.contains("CHROME")){
				Environment.put("SESSION_NAME", sessionName);
				d.fnCreateUnixlogValidationReport(Environment.get("CLASS_NAME"));
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Parameters({"browser"})
	@BeforeMethod
	public void beforeMethod(@Optional("") String browser, Method method){
		try{	
			String action = method.getName();
			System.out.println("Begin test : "+action);
			d.fGetDataForTest(action,Environment.get("CLASS_NAME"));
			if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
			{	
				driver = d.fGetWebDriver(driverType, action);
				d.fGuiHandleAuth(browser);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Reporter.driver = driver;
				Reporter.fnCreateHtmlReport(Dictionary.get("TEST_NAME"));
				objCommon = new CommonFunctions(driver, driverType, Environment,Reporter);
				Dictionary.put("TEST_NAME_"+ driverType, Dictionary.get("TEST_NAME"));
			}


		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_AddingWirelessRecieverOnDashboard_SummaryOfChangesPage_CheckoutPIP
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_adding Wireless reciever on dashboard_Summary of changes page_Checkout_PIP
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_FUNC_AddingWirelessRecieverOnDashboard_SummaryOfChangesPage_CheckoutPIP(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

/*			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}*/				//Commented because Special Offers page is out of scope - Kush Shah on 4/3/16

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.waitForTVReceiversIsDisplayed());
			Assert.assertTrue(dashboardPage.clickTVReceivers());
			Assert.assertTrue(dashboardPage.clickAddMoreReceivers());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickAddWirelessReceiver());
			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickYesIBOption());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
			Assert.assertTrue(personalInfoPage.checkSubmitOrderButtonisDisplayed());
			Assert.assertTrue(personalInfoPage.checkContinueButtonIsNotDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_NoAdditionalConfiguration_EligibleForExpressCHK
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_No Additional Configuration_eligible for Express CHK
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_FUNC_NoAdditionalConfiguration_EligibleForExpressCHK(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.fetchCurrentPlanNamesAndPrices("IPTV;HSIA"));

			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.clickChannelAddOns());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.addChannelsAddOns("Family-Friendly",Dictionary.get("IPTV_CHANNELS")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());            
			Assert.assertTrue(cartSummaryPage.checkCheckoutButtonIsNotDisplayed());
			Assert.assertTrue(cartSummaryPage.checkSubmitOrderButtonisDisplayed());

			ThankYouPageModify thankYouPage= cartSummaryPage.clickSubmit();
			Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
			Assert.assertTrue(thankYouPage.CheckOrderNumber());            
			Assert.assertTrue(thankYouPage.verifyHSIAPlanName(Dictionary.get("HSIA_PLAN")));
			Assert.assertTrue(thankYouPage.verifyIPTVPlanName(Dictionary.get("IPTV_PLAN")));
			Assert.assertTrue(thankYouPage.verifyProgrammingListContainsItem(Dictionary.get("IPTV_SPORT_CHANNEL")));


		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_ExpressCheckoutIneligibleOrder_AddingTV
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Express checkout Ineligible Order_adding TV
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_FUNC_ExpressCheckoutIneligibleOrder_AddingTV(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.checkAtLeaseOnePlanTile("IPTV"));
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayed());

			AddReceiversPageModify addReceiversPage = addChannelsPage.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPage.isPageDisplayed());

			InstallationAndEquipmentPageModify installationAndEquipment = addReceiversPage.clickContinue();
			Assert.assertTrue(installationAndEquipment.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipment.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			ScheduleInstallationPageModify scheduleInstallationPage = new ScheduleInstallationPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());


		}
	}       



	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_ExpressClosingPage_Submit_VerifyOrderIsNotFalloutAutomation
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Express closing page_Submit_verify Order is not fallout automation
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_FUNC_ExpressClosingPage_Submit_VerifyOrderIsNotFalloutAutomation(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"+"&offer_code="+Dictionary.get("HSIA_UPSELL")));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			ExpressCheckoutPageModify expressCheckoutPage = new ExpressCheckoutPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(expressCheckoutPage.isPageDisplayed());

			ThankYouPageModify thankYouPage= expressCheckoutPage.clickSubmitOrder();
			Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
			Assert.assertTrue(thankYouPage.CheckOrderNumber());           


		}
	}       



	//***************************************************************************************************
	//* NAME                : HSDS_AddInternet_VerifyingInternetTileStateWhenNewServicesAreDisplayed
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddInternet-P71338b-HardRock-Modify-60162_SN1_Verifying Internet Tile state when new services are displayed
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_AddInternet_VerifyingInternetTileStateWhenNewServicesAreDisplayed(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY&actionType=ChangeInternet"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());           

			AddInternetPageModify addInternetPage = new AddInternetPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addInternetPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("ADD_HSIA_PLAN")));

			Assert.assertTrue(addInternetPage.isPageDisplayed());

			SideCartModalModify SideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(SideCartModal.ValidateHSIAPlanAndPrice());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_AddInternet_VerifiyingCheckoutOptionOnAddInternetPage
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddInternet-P71338b-HardRock-Modify-60160_SN3_Verifiying Checkout Option on Add Internet Page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_AddInternet_VerifiyingCheckoutOptionOnAddInternetPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY&actionType=ChangeInternet"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			AddInternetPageModify addInternetPage = new AddInternetPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addInternetPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("ADD_HSIA_PLAN")));

			Assert.assertTrue(addInternetPage.isPageDisplayed());
			Assert.assertTrue(addInternetPage.clickContinue());

			InstallationAndEquipmentPageModify installationAndEquipmentPage = new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(installationAndEquipmentPage.isPageDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_VoiceDefault_VerifyButtonBarViewForVoiceDefaultPage
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_VoiceDefault-P71338b-HardRock-Modify-60260_SN1_verify  button bar view for Voice default  page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_VoiceDefault_VerifyButtonBarViewForVoiceDefaultPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickChangeVOIP());
			Assert.assertTrue(dashboardPage.checkTabAddSecondLineIsDisplayed());
			Assert.assertTrue(dashboardPage.checkTabVoicePlansIsDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_MiniCart_VerifyMiniCartIsDisplayedOnExpressClosingPage
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_MiniCart-P71338b-HardRock-Modify-60022_SN6_Verify mini cart is displayed on Express closing page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_MiniCart_VerifyMiniCartIsDisplayedOnExpressClosingPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"+"&destination_page=EXCHK&offer_code="+Dictionary.get("HSIA_UPSELL")));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			ExpressCheckoutPageModify expressCheckoutPage = new ExpressCheckoutPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(expressCheckoutPage.isPageDisplayed());
			Assert.assertTrue(expressCheckoutPage.fetchPlanFromExpressCheckoutNotice("HSIA"));

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.checkTabUpdatedCartIsDisplayed());
			Assert.assertTrue(sideCartModal.checkTabCurrentServicesIsDisplayed());
			Assert.assertTrue(sideCartModal.ValidateHSIAPanName());        

		}
	}       


	//***************************************************************************************************
	//* NAME                : MODCHK_PageContentsForDynamicCheckoutOnThankYouPage
	//* DESCRIPTION         : MODCHK-TYP-F060  Page Contents for Dynamic Checkout on Thank you page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void MODCHK_PageContentsForDynamicCheckoutOnThankYouPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY&actionType=ChangeInternet"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());           

			AddInternetPageModify addInternetPage = new AddInternetPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addInternetPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("ADD_HSIA_PLAN")));

			Assert.assertTrue(addInternetPage.isPageDisplayed());
			Assert.assertTrue(addInternetPage.clickContinue());

			InstallationAndEquipmentPageModify installationAndEquipmentPage = new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(installationAndEquipmentPage.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPage.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
			Assert.assertTrue(personalInfoPage.click911AddressRadio());
			Assert.assertTrue(personalInfoPage.ClickContinueBtn());     

			OptionalAutopayPageModify optionalAutoPayPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.selectCardType(Dictionary.get("CARD_TYPE")));
			Assert.assertTrue(optionalAutoPayPage.enterNameOnCard(Dictionary.get("NAME_ON_CARD")));
			Assert.assertTrue(optionalAutoPayPage.enterCardNumber(Dictionary.get("CARD_NUMBER")));
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.selectExpirationMonth(Dictionary.get("EXPIRATION_MONTH")));
			Assert.assertTrue(optionalAutoPayPage.selectExpirationYear(Dictionary.get("EXPIRATION_YEAR")));
			Assert.assertTrue(optionalAutoPayPage.clickAgreeAutoPayTC());
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());

			ReviewOrderPageModify reviewOrderPage=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

			ThankYouPageModify thankYouPage= reviewOrderPage.ClickOnSubmitOrder();
			Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());          
			Assert.assertTrue(thankYouPage.checkThankYouTextDisplayed());
			Assert.assertTrue(thankYouPage.checkOrderHasBeenPlacedTextDisplayed());
			Assert.assertTrue(thankYouPage.checkCHeckOrderStatusDisplayed());
			Assert.assertTrue(thankYouPage.checkManageMyAccountDisplayed());
			Assert.assertTrue(thankYouPage.checkShopMoreServicesDisplayed());
			//Assert.assertTrue(thankYouPage.checkManageMyAccountDisplayed());
			Assert.assertTrue(thankYouPage.checkOrderDateDisplayed());
			Assert.assertTrue(thankYouPage.CheckOrderNumber());
			Assert.assertTrue(thankYouPage.checkBillingAddressDisplayed());
			Assert.assertTrue(thankYouPage.checkServiceAddressDisplayed());                   
			Assert.assertTrue(thankYouPage.verifyHSIAPlanName(Dictionary.get("ADD_HSIA_PLAN")));

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_UI_SHOP_UVerseCustomer
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_SHOP-P71338b-HardRock-Modify-60060 - UVerse customer
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P1
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_UI_SHOP_UVerseCustomer(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(specialOffersPage.isPageDisplayed());

			Assert.assertTrue(specialOffersPage.verifyPageHeaderText());
			Assert.assertTrue(specialOffersPage.verifyEligibleMessageText());
			Assert.assertTrue(specialOffersPage.verifyPremiumOffersText());
			Assert.assertTrue(specialOffersPage.verifyPremiumOfferTileIsDisplayed());
			Assert.assertTrue(specialOffersPage.verifyMakeMoreChangesIsDisplayed());
			Assert.assertTrue(specialOffersPage.verifySideCartIsDisplayed());
			Assert.assertTrue(specialOffersPage.verifyPremiumOfferTileIsDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_ButtonNameIsChangedToRemoveAfterAddingEachAddOn
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddChannel-P71338b-HardRock-Modify-60142_SN1_ button name is changed to Remove after  adding each add-on
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_ButtonNameIsChangedToRemoveAfterAddingEachAddOn(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayed());
			Assert.assertTrue(addChannelsPage.addChannelsAddOns("Family-Friendly",Dictionary.get("IPTV_CHANNELS")));
			Assert.assertTrue(addChannelsPage.checkRemoveIsDisplayed("Family-Friendly",Dictionary.get("IPTV_CHANNELS")));           

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_VerifyBreadcrumbsServiceAddressOnlineChatAndContinueCTADisplayedOnDashboardTVReceiverPage
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddReceiver-P71338b-HardRock-Modify-60150_SN2_verify breadcrumbs,service address, online chat and continue CTA are displayed on Dashboard TV receiver page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_VerifyBreadcrumbsServiceAddressOnlineChatAndContinueCTADisplayedOnDashboardTVReceiverPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY&actionType=ChangeTV"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickTVReceivers());

			Assert.assertTrue(dashboardPage.isBreadcrumbDisplayed());
			Assert.assertTrue(dashboardPage.isAddressDisplayed());
			//no online chat

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.clickTVAdditionalCharges());
			Assert.assertTrue(sideCartModal.fetchWiredReceiversCount());

			Assert.assertTrue(dashboardPage.clickAddMoreReceivers());        
			Assert.assertTrue(dashboardPage.waitForReceiversPanelIsDisplayed());                
			Assert.assertTrue(dashboardPage.clickAddWirelessReceiver());
			Assert.assertTrue(dashboardPage.isPageDisplayed());      

			Assert.assertTrue(dashboardPage.clickAddMoreReceivers()); 
			Assert.assertTrue(dashboardPage.checkReceiversPanelIsDisplayed());
			Assert.assertTrue(dashboardPage.checkAddWiredReceiverIsDisplayed());
			Assert.assertTrue(dashboardPage.checkAddWirelessReceiverIsDisplayed());

			Assert.assertTrue(sideCartModal.checkWiredReceiversCountNotChanged());

			Assert.assertTrue(dashboardPage.clickCancelAddingReceivers());
			Assert.assertTrue(dashboardPage.clickAddMoreReceivers());
			Assert.assertTrue(dashboardPage.checkReceiversPanelIsDisplayed());
			Assert.assertTrue(dashboardPage.checkAddWiredReceiverIsDisplayed());
			Assert.assertTrue(dashboardPage.checkAddWirelessReceiverIsDisplayed());

			Assert.assertTrue(sideCartModal.checkWiredReceiversCountNotChanged());

			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());     
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());   

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_Modify_CustomerDetailsHavingIPTVandVOIPwithSingleLine
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddSecondLine-P71338b-HardRock-Modify-60281_SN3_customer details having IPTV and VOIP with single line
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME 
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Modify_CustomerDetailsHavingIPTVandVOIPwithSingleLine(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());           

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());           
			Assert.assertTrue(dashboardPage.clickChangeVOIP());
			Assert.assertTrue(dashboardPage.clickTabAddSecondLine());
			Assert.assertTrue(dashboardPage.waitForSectionAddSecondLineDisplayed());
			Assert.assertTrue(dashboardPage.clickAddSecondLineButton());
			Assert.assertTrue(dashboardPage.waitForRemoveSecondLineButtonDisplayed());

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.checkSecondPhoneLineIsDisplayed());    
			//invalid check : b. Checkout CTA and Change another Service CTA will be unhidden

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_VerifyAllIPTVplansShouldHaveCTAAddToCartWhenNewlyAddingServiceToCart
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddTV-P71338b-HardRock-Modify-60131_SN2_verify that all the IPTV plans  should have CTA Add to cart CTA when newly adding service to cart.
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_VerifyAllIPTVplansShouldHaveCTAAddToCartWhenNewlyAddingServiceToCart(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY&actionType=ChangeTV"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			AddTelevisionPageModify addTelevisionPage = new AddTelevisionPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.checkPlanNameOnOfferTileIsDisplayed());
			Assert.assertTrue(planTilesModal.checkChannelsNumberOnOfferTileIsDisplayed());
			Assert.assertTrue(planTilesModal.checkChannelsLogoOnOfferTileIsDisplayed()); 
			Assert.assertTrue(planTilesModal.checkCompareChanelsLineupOnOfferTileIsDisplayed());
			Assert.assertTrue(planTilesModal.checkAddToCartOnOfferTileIsDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_Modify_VerifyDashboardPageContent
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_DashBoard-P71338b-HardRock-Modify-60114_SN1_Verify Dashboard Page Content
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME 
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Modify_VerifyDashboardPageContent(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());           

		/*	SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());		//Special Offers Page is not more available for this test case.  -- Kush Shah on 3/7/16 for 16-02
			}
*/
			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());     
			Assert.assertTrue(dashboardPage.isAddressDisplayed());

			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			//Assert.assertTrue(dashboardPage.waitForCompareInternetPlansDisplayed());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.validateCurrentPlanInOfferTile("HSIA", Dictionary.get("CURRENT_HSIA_PLAN")));

			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.clickTVPlans());
			Assert.assertTrue(dashboardPage.waitForCompareTVPlansDisplayed());
			Assert.assertTrue(planTilesModal.validateCurrentPlanInOfferTile("IPTV", Dictionary.get("CURRENT_IPTV_PLAN")));

			Assert.assertTrue(dashboardPage.checkOrderOfServiceTiles(Dictionary.get("SERVICE_TILES_ORDER")));          

		}
	}    

	//***************************************************************************************************
	//* NAME                : HSDS_VerifyProgressBarIsInIncompleteStateTillTheConfigurationIsComplete
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Dashboard-P71338b-HardRock-Modify-60118_SN3_Verify that progress bar is in incomplete state till the configuration is complete
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME 
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_VerifyProgressBarIsInIncompleteStateTillTheConfigurationIsComplete(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddTelevisionProgressBarModify addTelevisionProgressBar = new AddTelevisionProgressBarModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addTelevisionProgressBar.checkProgressBarIsDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep1InProgressIsDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep2InProgressIsNotDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep3InProgressIsNotDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayed());

			Assert.assertTrue(addTelevisionProgressBar.checkStep1InProgressIsNotDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep2InProgressIsDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep3InProgressIsNotDisplayed()); 

			Assert.assertTrue(addChannelsPage.addChannelsAddOns("Family-Friendly",Dictionary.get("IPTV_CHANNELS")));          

			AddReceiversPageModify addReceiversPage = addChannelsPage.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPage.isPageDisplayed());

			Assert.assertTrue(addTelevisionProgressBar.checkStep1InProgressIsNotDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep2InProgressIsNotDisplayed());
			Assert.assertTrue(addTelevisionProgressBar.checkStep3InProgressIsDisplayed());
			InstallationAndEquipmentPageModify InstallationAndEquipmentPageModify = addReceiversPage.clickContinue();
			Assert.assertTrue(InstallationAndEquipmentPageModify.isPageDisplayed());

		}
	}

	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_InstallationEquip_SN2
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_InstallationEquip-P71338b-HardRock-Modify-60300_SN2
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_Desktop_Modify_FUNC_InstallationEquip_SN2(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);

			AddVoicePageModify addVoicePage=dashboardPage.clickSelectPlanVOIP();
			Assert.assertTrue(addVoicePage.isPageDisplayed());
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("ADD_VOIP_PLAN")));
			Assert.assertTrue(addVoicePage.isPageDisplayed());

			VoipConfigPageModify voipConfigPage = addVoicePage.clickNextChooseVoiceOptions();
			Assert.assertTrue(voipConfigPage.isPageDisplayed());
			Assert.assertTrue(voipConfigPage.clickGiveMeNewPhoneNumber());
			Assert.assertTrue(voipConfigPage.clickAdditionalInstallationNeedsNo());

			InstallationAndEquipmentPageModify installOptionsPage = voipConfigPage.clickContinue();
			Assert.assertTrue(installOptionsPage.isPageDisplayed());

			Assert.assertTrue(installOptionsPage.clickNoForPosQues());        
			Assert.assertTrue(installOptionsPage.validateCSIorFTIselected("CSI"));
			Assert.assertTrue(installOptionsPage.validateButtonAddNetworkInstallationNotDisplayed());

			Assert.assertTrue(installOptionsPage.clickYesForPosQues());
			Assert.assertTrue(installOptionsPage.isPageDisplayed());
			Assert.assertTrue(installOptionsPage.validateButtonAddNetworkInstallationIsDisplayed());

			CartSummaryPageModify cartSummaryPage = installOptionsPage.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());        

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_ExpressClosingPage_VerifyPageContent
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Express closing page_Verify page content
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME 
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_ExpressClosingPage_VerifyPageContent(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"+"&offer_code="+Dictionary.get("IPTV_UPSELL")));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			ExpressCheckoutPageModify expressCheckoutPage = new ExpressCheckoutPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(expressCheckoutPage.isPageDisplayed());

			Assert.assertTrue(expressCheckoutPage.checkBreadcrumbText("Home  /  Shop  /  Express Checkout"));
			//Verify Page title is displayed on Page As per the offer customer has taken (e.g.- Upgrade to Max Turbo etc) // Actual title: Express Checkout
			Assert.assertTrue(expressCheckoutPage.checkTitleText("Express Checkout"));

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.checkTabUpdatedCartIsDisplayed());
			Assert.assertTrue(sideCartModal.checkTabCurrentServicesIsDisplayed());
			Assert.assertTrue(expressCheckoutPage.fetchChannelFromExpressCheckoutNotice());
			Assert.assertTrue(sideCartModal.validateIPTVAdditionalChannels(Dictionary.get("CHANNEL_UPGRADE"), "Y"));

			Assert.assertTrue(expressCheckoutPage.checkOfferDetailsHasText());
			Assert.assertTrue(expressCheckoutPage.checkViewAllOffersLinkIsDisplayed());
			Assert.assertTrue(expressCheckoutPage.checkTwoMoreUpsellOffersDisplayed());
			Assert.assertTrue(expressCheckoutPage.checkSubmitOrderIsDisplayed());

			Assert.assertTrue(sideCartModal.clickTabCurrentServices());
			Assert.assertTrue(sideCartModal.ValidateIPTVPlanName(Dictionary.get("CURRENT_IPTV_PLAN")));
			Assert.assertTrue(sideCartModal.ValidateVOIPPlanName(Dictionary.get("CURRENT_VOIP_PLAN")));

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_ExpressClosingPage_VerifyPageTitleBreadcrumbsAndOfferDetailsOn
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Express closing page_verify page title, Breadcrumbs and offer details on
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_ExpressClosingPage_VerifyPageTitleBreadcrumbsAndOfferDetailsOn(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"+"&offer_code="+Dictionary.get("IPTV_UPSELL")));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			ExpressCheckoutPageModify expressCheckoutPage = new ExpressCheckoutPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(expressCheckoutPage.isPageDisplayed());

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.checkTabUpdatedCartIsDisplayed());
			Assert.assertTrue(sideCartModal.checkTabCurrentServicesIsDisplayed());
			Assert.assertTrue(expressCheckoutPage.fetchChannelFromExpressCheckoutNotice());
			Assert.assertTrue(sideCartModal.validateIPTVAdditionalChannels(Dictionary.get("CHANNEL_UPGRADE"), "Y"));  

			//Verify Page title is displayed on Page As per the offer customer has taken (e.g.- Upgrade to Max Turbo etc) // Actual title: Express Checkout
			Assert.assertTrue(expressCheckoutPage.checkTitleText("Express Checkout"));           
			Assert.assertTrue(expressCheckoutPage.checkOfferDetailsHasText());
			Assert.assertTrue(expressCheckoutPage.checkBreadcrumbText("Home  /  Shop  /  Express Checkout"));
			Assert.assertTrue(expressCheckoutPage.checkSubmitOrderIsDisplayed());

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_MulltiSectionBuyflow_ApplyNonEligibleCoupon
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Mullti Section Buyflow P71338b-HardRock-Modify-10220-  Apply Non-Eligible Coupon
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME 
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_MulltiSectionBuyflow_ApplyNonEligibleCoupon(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());           

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());   
			Assert.assertTrue(dashboardPage.clickChangeVOIP());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			objCommon.fCommonValidateDynamicPageDisplayed("", "");
			Assert.assertTrue(dashboardPage.clickVoicePlans());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			objCommon.fCommonValidateDynamicPageDisplayed("", "");
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("CHANGE_VOIP_PLAN")));

			Assert.assertTrue(dashboardPage.isPageDisplayed());

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.ValidateVOIPPlanName());   

			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());            
			Assert.assertTrue(cartSummaryPage.applyCouponCode(Dictionary.get("INVALID_COUPON")));
			Assert.assertTrue(cartSummaryPage.verifyInvalidCouponError());


		}
	}    


	//***************************************************************************************************
	//* NAME                : HSDS_VerifyNewlyAddedChannelsAndAddOnsAreGettingDisplayedInShowNewTabInMiniCartSection.
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_MiniCart-P71338b-HardRock-Modify-60047_SN1_Verify that newly added channels and add-ons are getting displayed in show new tab in mini cart section.
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME 
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_VerifyNewlyAddedChannelsAndAddOnsAreGettingDisplayedInShowNewTabInMiniCartSection(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayed());

			Assert.assertTrue(addChannelsPage.addChannelsAddOns("Family-Friendly",Dictionary.get("IPTV_CHANNELS")));
			Assert.assertTrue(addChannelsPage.isPageDisplayed());

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.checkTabCurrentServicesIsDisplayed());
			Assert.assertTrue(sideCartModal.ValidateIPTVPlanName());
			Assert.assertTrue(sideCartModal.validateIPTVAdditionalChannels(Dictionary.get("IPTV_CHANNELS"), "Y"));

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_UnknownRiskCustomer_CheckingReceiverRestriction
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_BuyFlow -P71338b-HardRock-Modify-60012_SN5_Unknown risk customer_checking Receiver restriction
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_UnknownRiskCustomer_CheckingReceiverRestriction(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.waitForTVReceiversIsDisplayed());
			Assert.assertTrue(dashboardPage.clickTVReceivers());

			//user has already 4 wired receivers; adding 4 more
			Assert.assertTrue(dashboardPage.clickAddMoreReceivers());        
			Assert.assertTrue(dashboardPage.waitForReceiversPanelIsDisplayed());
			Assert.assertTrue(dashboardPage.clickAddWiredReceiver());
			Assert.assertTrue(dashboardPage.isPageDisplayed()); 

			Assert.assertTrue(dashboardPage.clickAddMoreReceivers()); 
			Assert.assertTrue(dashboardPage.waitForReceiversPanelIsDisplayed());
			Assert.assertTrue(dashboardPage.clickAddWiredReceiver());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickAddMoreReceivers()); 
			Assert.assertTrue(dashboardPage.waitForReceiversPanelIsDisplayed());
			Assert.assertTrue(dashboardPage.clickAddWiredReceiver());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickAddMoreReceivers()); 
			Assert.assertTrue(dashboardPage.waitForReceiversPanelIsDisplayed());
			Assert.assertTrue(dashboardPage.clickAddWiredReceiver());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.checkAddMoreReceiversNotDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_CartSummary_RewardsSection
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_CartSummary-P71338b-HardRock-Modify-60350 - Rewards section
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_CartSummary_RewardsSection(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")));

			ShopLandingPage shopLandingPage= new ShopLandingPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(shopLandingPage.IsShopLandingPageDisplayed());
			Assert.assertTrue(shopLandingPage.ClickMyAtt());

			LoginFromOlamHardrock loginFromOlamHardrock = new LoginFromOlamHardrock(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginFromOlamHardrock.IsLoginFromOlamHardrockPageDisplayed());
			Assert.assertTrue(loginFromOlamHardrock.clickUverse());
			Assert.assertTrue(loginFromOlamHardrock.EnterUserID());
			Assert.assertTrue(loginFromOlamHardrock.EnterPassword());
			Assert.assertTrue(loginFromOlamHardrock.ClickLoginButton());

			AccountOverviewPage accountOverviewPage = new AccountOverviewPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
			Assert.assertTrue(accountOverviewPage.clickUVerseTV());
			Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
			Assert.assertTrue(accountOverviewPage.ClickChangePlan());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("ADD_HSIA_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.checkRewardsPanelDisplayed());
			Assert.assertTrue(cartSummaryPage.checkRewardItemsAreDisplayed());
			Assert.assertTrue(cartSummaryPage.checkLearMoreOnRewardItems());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_ContinueToCheckoutCTAWhenCartHasMoreThanOneExpressEligibleItem
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_CartSummary-P71338b-HardRock-Modify-60352 -  Continue to Checkout CTA when cart has more than one express eligible item
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_ContinueToCheckoutCTAWhenCartHasMoreThanOneExpressEligibleItem(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")));

			ShopLandingPage shopLandingPage= new ShopLandingPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(shopLandingPage.IsShopLandingPageDisplayed());
			Assert.assertTrue(shopLandingPage.ClickMyAtt());

			LoginFromOlamHardrock loginFromOlamHardrock = new LoginFromOlamHardrock(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginFromOlamHardrock.IsLoginFromOlamHardrockPageDisplayed());
			Assert.assertTrue(loginFromOlamHardrock.clickUverse());
			Assert.assertTrue(loginFromOlamHardrock.EnterUserID());
			Assert.assertTrue(loginFromOlamHardrock.EnterPassword());
			Assert.assertTrue(loginFromOlamHardrock.ClickLoginButton());

			AccountOverviewPage accountOverviewPage = new AccountOverviewPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
			Assert.assertTrue(accountOverviewPage.clickUVerseTV());
			Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
			Assert.assertTrue(accountOverviewPage.ClickChangePlan());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChannelAddOns());
			Assert.assertTrue(dashboardPage.addChannelsAddOns("Family-Friendly",Dictionary.get("IPTV_CHANNELS")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());          

			Assert.assertTrue(dashboardPage.clickChangeVOIP());
			Assert.assertTrue(dashboardPage.clickVoicePlans()); 
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("CHANGE_VOIP_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.checkSubmitOrderButtonisDisplayed());

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_MiniCartIsViewable
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_SHOP-P71338b-HardRock-Modify-60063 - Mini Cart is viewable
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_MiniCartIsViewable(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(specialOffersPage.isPageDisplayed());
			Assert.assertTrue(specialOffersPage.verifySideCartIsDisplayed());

		}
	}      


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_SHOP-P71338b-HardRock-Modify-60063 - Add multiple offers
	//* DESCRIPTION         : HSDS_AddMultipleOffers
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_AddMultipleOffers(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(specialOffersPage.isPageDisplayed());

			Assert.assertTrue(specialOffersPage.updatePlanPremiumOffers("IPTV",Dictionary.get("PREMIUM_OFFER_UPGRADE")));
			Assert.assertTrue(specialOffersPage.isPageDisplayed());
			Assert.assertTrue(specialOffersPage.checkRemoveButtonInPremiumOffers("IPTV", Dictionary.get("PREMIUM_OFFER_UPGRADE")));

			Assert.assertTrue(specialOffersPage.updatePlanChannelUpgradeOffers("CHANNEL_UPGRADE", Dictionary.get("CHANNEL_OFFER_UPGRADE")));
			Assert.assertTrue(specialOffersPage.isPageDisplayed());
			Assert.assertTrue(specialOffersPage.checkRemoveButtonInChannelUpgradeOffers("CHANNEL_UPGRADE",Dictionary.get("CHANNEL_OFFER_UPGRADE")));

		}
	}      


	//***************************************************************************************************
	//* NAME                : MODCHK-PIP-No Payment Page Scenario
	//* DESCRIPTION         : MODCHK_PIP_No_Payment_Page_Scenario
	//* AUTHOR              : Amit Kumar
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P3
	//* PREREQUISITE 		: Voluntary Autopay should Disable by Environment Team
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void MODCHK_PIP_No_Payment_Page_Scenario(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.waitForTVReceiversIsDisplayed());
			Assert.assertTrue(dashboardPage.clickTVReceivers());
			Assert.assertTrue(dashboardPage.clickAddMoreReceivers());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());            
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter); 
			installationAndEquipmentPageModify.isPageDisplayed();

		}
	}  

	//***************************************************************************************************
	//* NAME                : HSDS_ModifyOfferDetailsPageUI
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_SHOP-P71338b-HardRock-Modify-60090 - Modify Offer Details page _UI
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_ModifyOfferDetailsPageUI(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"+"&offer_code="+Dictionary.get("IPTV_UPSELL")+"&destination_page=MODP"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			OfferDetailsPageModify offerDetailsPage = new OfferDetailsPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(offerDetailsPage.isPageDisplayed());

			Assert.assertTrue(offerDetailsPage.checkBreadcrumbText("Home  /  Shop  /  Offer Details"));

			//Verify Online chat is available.  -->> no online chat

			Assert.assertTrue(offerDetailsPage.checkPageHeaderText(Dictionary.get("CHANNEL_OFFER_UPGRADE")));

			//Verify Image.For e.g offer image within the text box -->> no image for this offer code

			Assert.assertTrue(offerDetailsPage.checkOfferDetailsHasText());
			Assert.assertTrue(offerDetailsPage.checkUpdatePlanIsDisplayed());
			Assert.assertTrue(offerDetailsPage.checkDisclaimerHasText());
			Assert.assertTrue(offerDetailsPage.checkAddToCartForUpsellOffersIsDisplayed());
			Assert.assertTrue(offerDetailsPage.checkReturnToOtherOffersIsDisplayed());
		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_SpanishContent_AddVoipServiceToTheCart
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_Spanish Content - Add Voip Service to the cart
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_SpanishContent_AddVoipServiceToTheCart(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			GlobalNavMenu globalNavMenu = new GlobalNavMenu(driver, driverType, Dictionary, Environment, Reporter);            
			Assert.assertTrue(globalNavMenu.selectSpanishLang());
			Assert.assertTrue(globalNavMenu.clickSiContinuarSpanish());

			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());

			AddVoicePageModify addVoicePage=dashboardPage.clickSelectPlanVOIP();
			Assert.assertTrue(addVoicePage.isPageDisplayedSpanish());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("ADD_VOIP_PLAN")));
			Assert.assertTrue(addVoicePage.isPageDisplayedSpanish());

			VoipConfigPageModify voipConfigPage = addVoicePage.clickNextChooseVoiceOptions();
			Assert.assertTrue(voipConfigPage.isPageDisplayedSpanish());
			Assert.assertTrue(voipConfigPage.clickGiveMeNewPhoneNumber());
			Assert.assertTrue(voipConfigPage.clickAdditionalInstallationNeedsNo());

			InstallationAndEquipmentPageModify installOptionsPage = voipConfigPage.clickContinue();
			Assert.assertTrue(installOptionsPage.isPageDisplayedSpanish());     

		}
	}       


	//***************************************************************************************************
	//* NAME                : HSDS_SpanishContent_SummaryOfChange
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_Spanish content - Summary of Change
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_SpanishContent_SummaryOfChange(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("CHANGE_HSIA_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickContinue());

			InstallationAndEquipmentPageModify installationAndEquipmentPage = new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(installationAndEquipmentPage.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPage.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());

			GlobalNavMenu globalNavMenu = new GlobalNavMenu(driver, driverType, Dictionary, Environment, Reporter);            
			Assert.assertTrue(globalNavMenu.selectSpanishLang());
			Assert.assertTrue(globalNavMenu.clickSiContinuarSpanish());

			Assert.assertTrue(cartSummaryPage.isPageDisplayedSpanish());

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_SpanishContent_ExistingIPTVCustomer
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_Spanish content - Existing IPTV Customer
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_SpanishContent_ExistingIPTVCustomer(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			GlobalNavMenu globalNavMenu = new GlobalNavMenu(driver, driverType, Dictionary, Environment, Reporter);            
			Assert.assertTrue(globalNavMenu.selectSpanishLang());
			Assert.assertTrue(globalNavMenu.clickSiContinuarSpanish());

			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());
			Assert.assertTrue(dashboardPage.clickChangeIPTV()); 
			Assert.assertTrue(dashboardPage.clickChannelAddOns());
			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());
			Assert.assertTrue(dashboardPage.checkChannelLineUpLinkInSpanish());
			Assert.assertTrue(dashboardPage.clickTVReceivers());
			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());
			Assert.assertTrue(dashboardPage.checkTVReceiversSubHeaderInSpanish());

		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_SpanishContent_ValidatePersonalInfoPage
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_Spanish content - Validate personal info page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_SpanishContent_ValidatePersonalInfoPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			GlobalNavMenu globalNavMenu = new GlobalNavMenu(driver, driverType, Dictionary, Environment, Reporter);            
			Assert.assertTrue(globalNavMenu.selectSpanishLang());
			Assert.assertTrue(globalNavMenu.clickSiContinuarSpanish());

			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());

			AddVoicePageModify addVoicePage=dashboardPage.clickSelectPlanVOIP();
			Assert.assertTrue(addVoicePage.isPageDisplayedSpanish());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("ADD_VOIP_PLAN")));
			Assert.assertTrue(addVoicePage.isPageDisplayedSpanish());

			VoipConfigPageModify voipConfigPage = addVoicePage.clickNextChooseVoiceOptions();
			Assert.assertTrue(voipConfigPage.isPageDisplayedSpanish());
			Assert.assertTrue(voipConfigPage.clickGiveMeNewPhoneNumber());
			Assert.assertTrue(voipConfigPage.clickAdditionalInstallationNeedsNo());

			InstallationAndEquipmentPageModify installOptionsPage = voipConfigPage.clickContinue();
			Assert.assertTrue(installOptionsPage.isPageDisplayedSpanish());     

			dashboardPage=installOptionsPage.clickManageMyPlansAndServices();
			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayedSpanish());

			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayedSpanish());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayedSpanish());

			AddReceiversPageModify addReceiversPage = addChannelsPage.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPage.isPageDisplayedSpanish());

			InstallationAndEquipmentPageModify installationAndEquipment = addReceiversPage.clickContinue();
			Assert.assertTrue(installationAndEquipment.isPageDisplayedSpanish());

			CartSummaryPageModify cartSummaryPage = installationAndEquipment.clickContinue();
			Assert.assertTrue(cartSummaryPage.isPageDisplayedSpanish());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.isPageDisplayedSpanish());
			Assert.assertTrue(personalInfoPage.ClickContinueBtn());     

			OptionalAutopayPageModify paymentInfoPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(paymentInfoPage.isPageDisplayedSpanish());
			Assert.assertTrue(paymentInfoPage.clickAgreeAutoPayTC());
			Assert.assertTrue(paymentInfoPage.clickContinueWithAutoPay());
			Assert.assertTrue(paymentInfoPage.checkErrorMessageTextInSpanish());


		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_SpanishContent_ValidateThankYouPage
	//* DESCRIPTION         : HSDS_Desktop_Modify_UI_Spanish content - Validate Thank you page
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_SpanishContent_ValidateThankYouPage(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			GlobalNavMenu globalNavMenu = new GlobalNavMenu(driver, driverType, Dictionary, Environment, Reporter);            
			Assert.assertTrue(globalNavMenu.selectSpanishLang());
			Assert.assertTrue(globalNavMenu.clickSiContinuarSpanish());

			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());

			AddVoicePageModify addVoicePage=dashboardPage.clickSelectPlanVOIP();
			Assert.assertTrue(addVoicePage.isPageDisplayedSpanish());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("ADD_VOIP_PLAN")));
			Assert.assertTrue(addVoicePage.isPageDisplayedSpanish());

			VoipConfigPageModify voipConfigPage = addVoicePage.clickNextChooseVoiceOptions();
			Assert.assertTrue(voipConfigPage.isPageDisplayedSpanish());
			Assert.assertTrue(voipConfigPage.clickGiveMeNewPhoneNumber());
			Assert.assertTrue(voipConfigPage.clickAdditionalInstallationNeedsNo());

			InstallationAndEquipmentPageModify installOptionsPage = voipConfigPage.clickContinue();
			Assert.assertTrue(installOptionsPage.isPageDisplayedSpanish());     

			dashboardPage=installOptionsPage.clickManageMyPlansAndServices();
			Assert.assertTrue(dashboardPage.isPageDisplayedSpanish());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayedSpanish());

			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayedSpanish());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayedSpanish());

			AddReceiversPageModify addReceiversPage = addChannelsPage.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPage.isPageDisplayedSpanish());

			InstallationAndEquipmentPageModify installationAndEquipment = addReceiversPage.clickContinue();
			Assert.assertTrue(installationAndEquipment.isPageDisplayedSpanish());

			CartSummaryPageModify cartSummaryPage = installationAndEquipment.clickContinue();
			Assert.assertTrue(cartSummaryPage.isPageDisplayedSpanish());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.isPageDisplayedSpanish());
			Assert.assertTrue(personalInfoPage.ClickContinueBtn());     

			OptionalAutopayPageModify paymentInfoPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(paymentInfoPage.isPageDisplayedSpanish());
			Assert.assertTrue(paymentInfoPage.clickAgreeAutoPayTC());

			ScheduleInstallationPageModify scheduleInstallationPage=paymentInfoPage.clickContinueWithoutAutoPay();
			Assert.assertTrue(scheduleInstallationPage.isPageDisplayedSpanish());
			Assert.assertTrue(scheduleInstallationPage.waitForContactPhoneNumber());
			Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

			ReviewOrderPageModify reviewOrderPage=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(reviewOrderPage.isPageDisplayedSpanish());

			ThankYouPageModify thankYouPage= reviewOrderPage.ClickOnSubmitOrder();
			Assert.assertTrue(thankYouPage.isPageDisplayedSpanish());

		}
	}       



	//***************************************************************************************************
	//* NAME                : HSDS_LowCreditCreditCardValidationFails_ContinueWithoutAutopayModal
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Low Credit_Credit Card Validation Fails_Continue without Autopay Modal
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({"browser"})
	public void HSDS_LowCreditCreditCardValidationFails_ContinueWithoutAutopayModal(@Optional("") String browser) 
	{
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddChannelsPageModify  addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayed());

			AddReceiversPageModify addReceiversPage = addChannelsPage.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPage.isPageDisplayed());

			InstallationAndEquipmentPageModify installationAndEquipment = addReceiversPage.clickContinue();
			Assert.assertTrue(installationAndEquipment.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipment.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			OptionalAutopayPageModify optionalAutoPayPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());

			//1st attempt
			Assert.assertTrue(optionalAutoPayPage.selectCardType(Dictionary.get("CARD_TYPE")));
			Assert.assertTrue(optionalAutoPayPage.enterNameOnCard(Dictionary.get("NAME_ON_CARD")));
			Assert.assertTrue(optionalAutoPayPage.enterCardNumber(Dictionary.get("CARD_NUMBER")));
			Assert.assertTrue(optionalAutoPayPage.selectExpirationMonth(Dictionary.get("EXPIRATION_MONTH")));
			Assert.assertTrue(optionalAutoPayPage.selectExpirationYear(Dictionary.get("EXPIRATION_YEAR")));
			Assert.assertTrue(optionalAutoPayPage.clickAgreeAutoPayTC());
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());           
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkErrorMessageSectionDisplayed());

			//2nd attempt
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());           
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkErrorMessageSectionDisplayed());

			//3rd attempt
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());       
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkErrorMessageSectionDisplayed());

			//4th attempt
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());        
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkErrorMessageSectionDisplayed());

			//5th attempt
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());           
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkErrorMessageSectionDisplayed());


			//6th attempt
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());           
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkErrorMessageSectionDisplayed());

			//7th attempt
			Assert.assertTrue(optionalAutoPayPage.enterCardSecurityCode(Dictionary.get("CARD_CVV")));
			Assert.assertTrue(optionalAutoPayPage.clickContinueWithAutoPay());            
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());

			UnableAutoPayModalModify unableAutoPay = new UnableAutoPayModalModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(unableAutoPay.isModalDisplayed());
			Assert.assertTrue(unableAutoPay.checkBodyText());
			Assert.assertTrue(unableAutoPay.clickContinueWithoutAutoPay());

			ScheduleInstallationPageModify scheduleInstallationPage=new ScheduleInstallationPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
			Assert.assertTrue(scheduleInstallationPage.waitForContactPhoneNumber());
			Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

			ReviewOrderPageModify reviewOrderPage=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());


		}
	}       

	//***************************************************************************************************
	//* NAME                : HSDS_LowCreditVoluntaryAutopay_PageUIContent
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Low Credit_Voluntary Autopay_Page UI Content
	//* AUTHOR              : Gavril Grigorean
	//* STATUS              : TEST COMPLETED SUCCESSFUL IN FIREFOX AND CHROME
	//* PRIORITY            : P2
	//***************************************************************************************************
	@Test
	@Parameters({ "browser" })
	public void HSDS_LowCreditVoluntaryAutopay_PageUIContent(
			@Optional("") String browser) {
		if (Dictionary.get("SKIP_" + driverType).equalsIgnoreCase("")) {
			driver.manage().deleteAllCookies();

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL") + "login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary,Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			SpecialOffersPageModify specialOffersPage = new SpecialOffersPageModify(driver, driverType, Dictionary, Environment, Reporter);
			if (specialOffersPage.isPageDisplayed())
			{
				Assert.assertTrue(specialOffersPage.clickMakeMoreChanges());
			}

			DashboardPageModify dashboardPage = new DashboardPageModify(driver,driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPage = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver,driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPage.isPageDisplayed());

			AddChannelsPageModify addChannelsPage = addTelevisionPage.clickNextChannelAddOns();
			Assert.assertTrue(addChannelsPage.isPageDisplayed());
			Assert.assertTrue(addChannelsPage.addChannelsAddOns("Family-Friendly", Dictionary.get("IPTV_CHANNELS")));
			Assert.assertTrue(addChannelsPage.isPageDisplayed());

			AddReceiversPageModify addReceiversPage = addChannelsPage.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPage.isPageDisplayed());
			Assert.assertTrue(addReceiversPage.clickAddMoreReceivers());
			Assert.assertTrue(addReceiversPage.waitForReceiversPanelIsDisplayed());
			Assert.assertTrue(addReceiversPage.clickAddWiredReceiver());
			Assert.assertTrue(addReceiversPage.isPageDisplayed());

			dashboardPage = addReceiversPage.clickChangeAnotherService();
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddVoicePageModify addVoicePage = dashboardPage.clickSelectPlanVOIP();
			Assert.assertTrue(addVoicePage.isPageDisplayed());
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("ADD_VOIP_PLAN")));
			Assert.assertTrue(addVoicePage.isPageDisplayed());

			VoipConfigPageModify addVoiceOptionsPage = addVoicePage.clickNextChooseVoiceOptions();
			Assert.assertTrue(addVoiceOptionsPage.isPageDisplayed());
			Assert.assertTrue(addVoiceOptionsPage.clickGiveMeNewPhoneNumber());
			Assert.assertTrue(addVoiceOptionsPage.clickAdditionalInstallationNeedsYes());

			InstallationAndEquipmentPageModify installOptionsPage = addVoiceOptionsPage.clickContinue();
			Assert.assertTrue(installOptionsPage.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installOptionsPage.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
			Assert.assertTrue(personalInfoPage.ClickContinueBtn());

			OptionalAutopayPageModify optionalAutoPayPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(optionalAutoPayPage.isPageDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkSectionTitleText()); 
			Assert.assertTrue(optionalAutoPayPage.checkInstrunctionalTextIsDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkImportantAutopayTextIsDisplayed());
			Assert.assertTrue(optionalAutoPayPage.checkCardTypeIsNotPrePopulated());
			Assert.assertTrue(optionalAutoPayPage.checkNameOnCardValueHasSpace());
			Assert.assertTrue(optionalAutoPayPage.checkCardNumberTextField());
			Assert.assertTrue(optionalAutoPayPage.checkCardCVVNumericField());
			Assert.assertTrue(optionalAutoPayPage.checkMonthDefaultValue());
			Assert.assertTrue(optionalAutoPayPage.checkYearDefaultValue());
			Assert.assertTrue(optionalAutoPayPage.checkCardBillingAddressDefaultChecked());
			Assert.assertTrue(optionalAutoPayPage.clickUseDifferentAddress());
			Assert.assertTrue(optionalAutoPayPage.checkStreetAddressLine1Length());
			Assert.assertTrue(optionalAutoPayPage.checkStreetAddressLine2Length());
			Assert.assertTrue(optionalAutoPayPage.checkCityLength());
			Assert.assertTrue(optionalAutoPayPage.checkStateDefaultValue());
			Assert.assertTrue(optionalAutoPayPage.checkZipCodeNumericAndLenght());      

		}
	}

	//***************************************************************************************************
	//* NAME                : ExistingUverseCustomer_addingIPTV_U200_Rejecting_ETF
	//* DESCRIPTION         : Existing Uverse Customer with existing HSIA +VOIP Services_Customer adding IPTV U200 _Rejecting ETF
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : 
	//* PRIORITY            : 
	//***************************************************************************************************
	@Test
	@Parameters({ "browser" })
	public void ExistingUverseCustomer_addingIPTV_U200_Rejecting_ETF(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPageModify = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			Assert.assertTrue(addTelevisionPageModify.clickShowPlanOptions());
			Assert.assertTrue(addTelevisionPageModify.selectTVservice("IPTV"));
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			Assert.assertTrue(addTelevisionPageModify.selectTVPlan("U200"));
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			Assert.assertTrue(addTelevisionPageModify.clickContinue());

			AddChannelsPageModify addChannelsPageModify = new AddChannelsPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addChannelsPageModify.isPageDisplayed());

			AddReceiversPageModify addReceiversPageModify = addChannelsPageModify.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPageModify.isPageDisplayed());
			Assert.assertTrue(addReceiversPageModify.selectTVReceivers_Uverse("1", "Wired"));

			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = addReceiversPageModify.clickContinue();
			Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPageModify.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickYesIBOption());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());
			/*
			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
			Assert.assertTrue(personalInfoPage.checkSubmitOrderButtonisDisplayed());
			Assert.assertTrue(personalInfoPage.checkContinueButtonIsNotDisplayed());*/

			OptionalAutopayPageModify paymentInfoPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(paymentInfoPage.isPageDisplayed());

			ScheduleInstallationPageModify scheduleInstallationPage=paymentInfoPage.clickContinueWithoutAutoPay();
			Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
			Assert.assertTrue(scheduleInstallationPage.EnterPrimaryPhone());
			Assert.assertTrue(scheduleInstallationPage.EnterLastName("Amdocs"));
			Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

			ReviewOrderPageModify reviewOrderPage=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

			/*Comment out the submit step to avoid data burn out
			ThankYouPageModify thankYouPage= reviewOrderPage.ClickOnSubmitOrder();
			Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
			 */
		}
	}

	//***************************************************************************************************
	//* NAME                : ExistingUverseCustomerwithHSIA
	//* DESCRIPTION         : Existing Uverse Customer with HSIA
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : 
	//* PRIORITY            : 
	//***************************************************************************************************
	@Test
	@Parameters({ "browser" })
	public void ExistingUverseCustomerwithHSIA(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPageModify = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			/*For some accounts, DTV plans will show up first. So we need to switch to IPTV first
			Assert.assertTrue(addTelevisionPageModify.clickShowPlanOptions());
			Assert.assertTrue(addTelevisionPageModify.selectTVservice("IPTV"));
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());*/
			Assert.assertTrue(addTelevisionPageModify.selectTVPlan("U-basic"));
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			Assert.assertTrue(addTelevisionPageModify.clickContinue());

			AddChannelsPageModify addChannelsPageModify = new AddChannelsPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addChannelsPageModify.isPageDisplayed());

			AddReceiversPageModify addReceiversPageModify = addChannelsPageModify.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPageModify.isPageDisplayed());
			Assert.assertTrue(addReceiversPageModify.selectTVReceivers_Uverse("1", "THD"));
			//Verify customer will pay the fee for THD
			SideCartModalModify sideCartModalModify = new SideCartModalModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModalModify.clickTVAdditionalCharges());
			sideCartModalModify.validateTHDinCart();


			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = addReceiversPageModify.clickContinue();
			Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPageModify.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());   
			Assert.assertTrue(cartSummaryPage.ClickYesIBOption());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());
			/*
			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
			Assert.assertTrue(personalInfoPage.checkSubmitOrderButtonisDisplayed());
			Assert.assertTrue(personalInfoPage.checkContinueButtonIsNotDisplayed());*/

			OptionalAutopayPageModify paymentInfoPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(paymentInfoPage.isPageDisplayed());

			ScheduleInstallationPageModify scheduleInstallationPage=paymentInfoPage.clickContinueWithoutAutoPay();
			Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
			Assert.assertTrue(scheduleInstallationPage.EnterPrimaryPhone());
			Assert.assertTrue(scheduleInstallationPage.EnterLastName("Amdocs"));
			Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

			ReviewOrderPageModify reviewOrderPage=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

			/*Comment out the submit step to avoid data burn out
			ThankYouPageModify thankYouPage= reviewOrderPage.ClickOnSubmitOrder();
			Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
			 */
		}
	}


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_AddInternet_Verifying_Internet_Tiles
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_AddInternet-P71338b-HardRock-Modify-60161_SN1_Verifying Internet Tiles
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : 
	//* PRIORITY            : 
	//***************************************************************************************************
	@Test
	@Parameters({ "browser" })
	public void HSDS_Desktop_Modify_FUNC_AddInternet_Verifying_Internet_Tiles(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.verifyHSIAtileInformation());		
		}

	}

	//***************************************************************************************************
	//* NAME                : Accessing_Modify_Pages_unauthenticated
	//* DESCRIPTION         : Accessing Modify Pages unauthenticated
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : 
	//* PRIORITY            : 
	//***************************************************************************************************
	@Test
	@Parameters({ "browser" })
	public void Accessing_Modify_Pages_unauthenticated(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			driver.get(Environment.get("HROCK_NC")+"u-verse/build-your-own-bundle.html");
			BYOBPage bYOBPage = new BYOBPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(bYOBPage.BYOBPageIsDisplayed());
			Assert.assertTrue(bYOBPage.ClickToStayOnBYOBorBackToDashBoard("N"));
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			driver.get(Environment.get("HROCK_NC")+"u-verse/build-your-own-bundle.html");
			bYOBPage = new BYOBPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(bYOBPage.BYOBPageIsDisplayed());
			Assert.assertTrue(bYOBPage.ClickToStayOnBYOBorBackToDashBoard("Y"));
			CheckAvailabilityPage checkAvailabilityPage = new CheckAvailabilityPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(checkAvailabilityPage.IsPageDisplayed());

			//driver.manage().deleteAllCookies();
			driver.get(Environment.get("HROCK_NC")+"myuverse/dashboard.html");
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());


		}

	}

	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_BuyFlow_High_Risk_customer_already_having_International
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_BuyFlow -P71338b-HardRock-Modify-60012_SN3_High risk customer already having International
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : 
	//* PRIORITY            : 
	//***************************************************************************************************	
	@Test
	@Parameters({ "browser" })
	public void HSDS_Desktop_Modify_FUNC_BuyFlow_High_Risk_customer_already_having_International(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeVOIP());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			//Verify All VOIP plans are displayed
			Assert.assertTrue(planTilesModal.checkPlanNameOnOfferTileIsDisplayed());
			Assert.assertTrue(planTilesModal.addToCartPlan("VOIP",Dictionary.get("CHANGE_VOIP_PLAN")));

			Assert.assertTrue(dashboardPage.isPageDisplayed());

			SideCartModalModify sideCartModal = new SideCartModalModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(sideCartModal.ValidateVOIPPlanName());   

			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = new InstallationAndEquipmentPageModify(driver, driverType,Dictionary, Environment, Reporter);
			Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPageModify.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());   

		}

	}

	//***************************************************************************************************
	//* NAME                : ExistingUverseCustomer_with_existing_HSIA_max_Customer_Upgrading_to_HSIATurbo_FTI
	//* DESCRIPTION         : Existing Uverse Customer with existing HSIA max_Customer Upgrading to HSIA Turbo_FTI
	//* AUTHOR              : Kaiqi Tang

	//* STATUS              : 
	//* PRIORITY            : 
	//***************************************************************************************************	
	@Test
	@Parameters({ "browser" })
	public void ExistingUverseCustomer_with_existing_HSIA_max_Customer_Upgrading_to_HSIATurbo_FTI(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("CHANGE_HSIA_PLAN")));

			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());   
			/*Comment out the submit step to avoid data burn out
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			ThankYouPageModify thankYouPageModify = new ThankYouPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(thankYouPageModify.ThankyouPageIsDisplayed());
			 */

		}

	}	

	//***************************************************************************************************
	//* NAME                : ExistingUverseCustomer_Low_risk_Customer_with_existing_IPTV_UBasic_Upgrading_to_all_three_services
	//* DESCRIPTION         : Existing Uverse Customer_Low risk_Customer with existing IPTV  U Basic _Upgrading to all three services
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : Need correct data to complete
	//* PRIORITY            : 
	//***************************************************************************************************	
	@Test
	@Parameters({ "browser" })
	public void ExistingUverseCustomer_Low_risk_Customer_with_existing_IPTV_UBasic_Upgrading_to_all_three_services(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("CHANGE_HSIA_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());			
			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickTVPlans());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("CHANGE_IPTV_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeVOIP());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickTabAddSecondLine());
			Assert.assertTrue(dashboardPage.clickAddSecondLineButton());
			Assert.assertTrue(dashboardPage.selectVOIPAdditionalInstallationNeeds("No"));
			//Assert.assertTrue(dashboardPage.);			Assert.assertTrue(dashboardPage.isPageDisplayed());

			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());
			Assert.assertTrue(installationAndEquipmentPageModify.selectInternetandPhoneInstallation("No"));

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPageModify.clickContinue ();
			UnificationPage unificationPage = new UnificationPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(unificationPage.UnificationPageDisplayed());
			Assert.assertTrue(unificationPage.ClickNoThanksCTA());

			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());   

			/*Comment out the submit step to avoid data burn out
			Assert.assertTrue(cartSummaryPage.ClickCheckout());

			ThankYouPageModify thankYouPageModify = new ThankYouPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(thankYouPageModify.ThankyouPageIsDisplayed());
			 */

		}

	}

	//***************************************************************************************************
	//* NAME                : ExistingUnifiedUverse_wirelessCustomerwithexistingHSIAmaxplus_adding_IPTV_U_Basic_total_home_DVR_Add_Support_PlusAndHNI
	//* DESCRIPTION         : Existing Unified Uverse+wireless Customer with existing HSIA max plus_adding IPTV U Basic_total home DVR_Add Support Plus and HNI
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : Need correct data to complete
	//* PRIORITY            : 
	//***************************************************************************************************	
	@Test
	@Parameters({ "browser" })
	public void ExistingUnifiedUverse_wirelessCustomerwithexistingHSIAmaxplus_adding_IPTV_U_Basic_total_home_DVR_Add_Support_PlusAndHNI(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			AddTelevisionPageModify addTelevisionPageModify = dashboardPage.clickSelectPlanIPTV();
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			Assert.assertTrue(addTelevisionPageModify.clickShowPlanOptions());
			Assert.assertTrue(addTelevisionPageModify.selectTVservice("Uverse"));
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV", Dictionary.get("ADD_IPTV_PLAN")));
			Assert.assertTrue(addTelevisionPageModify.isPageDisplayed());
			Assert.assertTrue(addTelevisionPageModify.clickContinue());


			AddChannelsPageModify addChannelsPageModify = new AddChannelsPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(addChannelsPageModify.isPageDisplayed());

			AddReceiversPageModify addReceiversPageModify = addChannelsPageModify.clickNextAddTVReceivers();
			Assert.assertTrue(addReceiversPageModify.isPageDisplayed());
			Assert.assertTrue(addReceiversPageModify.selectTVReceivers_Uverse("1", "DVR"));

			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = addReceiversPageModify.clickContinue();
			Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPageModify.clickContinue ();
			UnificationPage unificationPage = new UnificationPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(unificationPage.UnificationPageDisplayed());
			Assert.assertTrue(unificationPage.ClickNoThanksCTA());

			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			Assert.assertTrue(cartSummaryPage.ClickYesIBOption());
			Assert.assertTrue(cartSummaryPage.ClickCheckout());
			/*
			PersonalInfoPageModify personalInfoPage = new PersonalInfoPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(personalInfoPage.IsPersonalInfoPageDisplayed());
			Assert.assertTrue(personalInfoPage.checkSubmitOrderButtonisDisplayed());
			Assert.assertTrue(personalInfoPage.checkContinueButtonIsNotDisplayed());*/

			OptionalAutopayPageModify paymentInfoPage = new OptionalAutopayPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(paymentInfoPage.isPageDisplayed());

			ScheduleInstallationPageModify scheduleInstallationPage=paymentInfoPage.clickContinueWithoutAutoPay();
			Assert.assertTrue(scheduleInstallationPage.VerifyScheduleInformationPage());
			Assert.assertTrue(scheduleInstallationPage.ClickOnContinue());

			ReviewOrderPageModify reviewOrderPage=new ReviewOrderPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(reviewOrderPage.IsReviewOrderPageDisplayed());

			/*Comment out the submit step to avoid data burn out
			ThankYouPageModify thankYouPage= reviewOrderPage.ClickOnSubmitOrder();
			Assert.assertTrue(thankYouPage.ThankyouPageIsDisplayed());
			 */


		}

	}


	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_CartSummary_Installation_date_and_reward
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_CartSummary-P71338b-HardRock-Modify-60350 - Installation date and reward
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : Need correct data to complete
	//* PRIORITY            : 
	//***************************************************************************************************	
	@Test
	@Parameters({ "browser" })
	public void HSDS_Desktop_Modify_FUNC_CartSummary_Installation_date_and_reward(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase(""))
		{   
			driver.manage().deleteAllCookies();     

			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")));

			ShopLandingPage shopLandingPage= new ShopLandingPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(shopLandingPage.IsShopLandingPageDisplayed());
			Assert.assertTrue(shopLandingPage.ClickMyAtt());

			LoginFromOlamHardrock loginFromOlamHardrock = new LoginFromOlamHardrock(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginFromOlamHardrock.IsLoginFromOlamHardrockPageDisplayed());
			Assert.assertTrue(loginFromOlamHardrock.clickUverse());
			Assert.assertTrue(loginFromOlamHardrock.EnterUserID());
			Assert.assertTrue(loginFromOlamHardrock.EnterPassword());
			Assert.assertTrue(loginFromOlamHardrock.ClickLoginButton());

			AccountOverviewPage accountOverviewPage = new AccountOverviewPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
			Assert.assertTrue(accountOverviewPage.clickUVerseTV());
			Assert.assertTrue(accountOverviewPage.CheckAccountOverviewPageExist());
			Assert.assertTrue(accountOverviewPage.ClickChangePlan());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("CHANGE_IPTV_PLAN")));

			DowngradeModal downgradeModal = new DowngradeModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(downgradeModal.IsDowngradeModalDisplayed());
			Assert.assertTrue(downgradeModal.selectToDowngrade());
			Assert.assertTrue(downgradeModal.clickToConitnue());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeHSIA());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(planTilesModal.addToCartPlan("HSIA",Dictionary.get("CHANGE_HSIA_PLAN")));
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickContinue());

			InstallationAndEquipmentPageModify installationAndEquipmentPageModify = new InstallationAndEquipmentPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(installationAndEquipmentPageModify.isPageDisplayed());

			CartSummaryPageModify cartSummaryPage = installationAndEquipmentPageModify.clickContinue();
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());
			//Verify Cart summary page displays next available Installation date and reward applicble to order on top of the page.
			//Assert.assertTrue(cartSummaryPage.);

		}

	}	

	//***************************************************************************************************
	//* NAME                : HSDS_Desktop_Modify_FUNC_Mullti_Section_Buyflow_Express_Checkout_Change_TV_Plan
	//* DESCRIPTION         : HSDS_Desktop_Modify_FUNC_Mullti Section Buyflow P71338b-HardRock-Modify-10240- Express Checkout - Change TV Plan
	//* AUTHOR              : Kaiqi Tang
	//* STATUS              : Need correct data to complete
	//* PRIORITY            : 
	//***************************************************************************************************	
	@Test
	@Parameters({ "browser" })
	public void HSDS_Desktop_Modify_FUNC_Mullti_Section_Buyflow_Express_Checkout_Change_TV_Plan(@Optional("") String browser){
		if (Dictionary.get("SKIP_"+driverType).equalsIgnoreCase("")){   
			Assert.assertTrue(objCommon.fCommonLaunchEnvironemnt(Environment.get("WBFC_MODIFY_URL")+"login/login.html?wlsfi=MODIFY"));

			LoginPage loginPage = new LoginPage(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(loginPage.LoginPageIsDisplayed());
			Assert.assertTrue(loginPage.EnterUserDetailsAndPassword());

			DashboardPageModify dashboardPage = new DashboardPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickChangeIPTV());
			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.clickTVPlans());
			Assert.assertTrue(dashboardPage.isPageDisplayed());

			PlanTilesModal planTilesModal = new PlanTilesModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(planTilesModal.addToCartPlan("IPTV",Dictionary.get("CHANGE_IPTV_PLAN")));

			DowngradeModal downgradeModal = new DowngradeModal(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(downgradeModal.IsDowngradeModalDisplayed());
			Assert.assertTrue(downgradeModal.selectToDowngrade());
			Assert.assertTrue(downgradeModal.clickToConitnue());

			Assert.assertTrue(dashboardPage.isPageDisplayed());
			Assert.assertTrue(dashboardPage.waitForContinueisEnabled());
			Assert.assertTrue(dashboardPage.clickContinue());

			CartSummaryPageModify cartSummaryPage = new CartSummaryPageModify(driver, driverType, Dictionary, Environment, Reporter);
			Assert.assertTrue(cartSummaryPage.IsCartSummaryDisplayed());   
		}

	}	


	@Parameters({"browser"})
	@AfterMethod
	public void afterMethod(Method method, ITestResult result,@Optional("") String browser) throws Exception{

		driverType = browser;
		try{
			if (Dictionary.get("SKIP_"+ driverType).equals("") && !Dictionary.get("SKIP_"+driverType).equals("null"))
			{ 
				//System.out.println("AfterMethod begin - " + method.getName());
				//String status;

				if (result.getStatus() == ITestResult.SUCCESS){
					Dictionary.put("RESULT_" + driverType, "P");
					Driver.QCHashMap.put("RESULT_" + driverType, "P");

					Dictionary.put("QC_STATUS", "Passed");
					Driver.QCHashMap.put("QC_STATUS", "Passed");
				}
				else if(result.getStatus() == ITestResult.FAILURE){
					Dictionary.put("RESULT_" + driverType, "F");
					Driver.QCHashMap.put("RESULT_" + driverType, "F");

					Dictionary.put("QC_STATUS", "Failed");
					Driver.QCHashMap.put("QC_STATUS", "Failed");
				}
				else {
					Dictionary.put("RESULT_" + driverType, "N");
					Driver.QCHashMap.put("RESULT_" + driverType, "N");

					Dictionary.put("QC_STATUS", "Passed");
					Driver.QCHashMap.put("QC_STATUS", "Passed");
					System.out.println("Invalid Status");
				}
				System.out.println("Result - " + driverType + " - " + result.toString());
				d.fUpdateTestCaseRowSkip(Integer.parseInt(Dictionary.get("SKIPROW_" + driverType)));

				//Close Summary Report
				Reporter.fnCloseHtmlReport();

				//Get OS and Browser Version Information
				Dictionary.put("OS_BROWSER_VER", d.FindOSBrowserVer(driver));

				Driver.QCHashMap.put("TEST_NAME_", Dictionary.get("TEST_NAME_"+ driverType) + "_" + driverType);
				Driver.QCHashMap.put("OS_BROWSER_VER", d.FindOSBrowserVer(driver));
				Driver.QCHashMap.put("STEP", Dictionary.get("STEP"));
				Driver.QCHashMap.put("QC_UPDATE", Environment.get("QC_UPDATE"));

				//validate logs if the test passes:
				if(!Environment.get("UNIX_LOG_VALIDATION").toLowerCase().equals("no") && Environment.get("UNIX_LOG_VALIDATION") != null){	
					if (Driver.QCHashMap.get("QC_STATUS").contains("Passed") ){
						String Errors = objCommon.fGetErrorFromUnixLogs(Environment.get("SESSION_ID"));
						Environment.put("LOG_ERRORS", Errors);
						d.UpdateTestFlowErrorsToUNIXLogFile();
					}
				}

				try {
					// creates the new thread to run QCUpdate in background
					Thread thread = new Thread(new Runnable(){
						public void run(){
							if(System.getProperty("qcUpdateInd") == null){
								if(Driver.QCHashMap.get("QC_UPDATE").equalsIgnoreCase("Y")){
									Object sTestid = d.fAddTest(Driver.QCHashMap.get("TEST_NAME_"));
									Driver.QCHashMapTestId.put("sTestid",sTestid);
									d.fUpdateTestStatQC(Driver.QCHashMap.get("TEST_NAME_"), Driver.QCHashMapTestId.get("sTestid"), Driver.QCHashMap.get("QC_STATUS"), Driver.QCHashMap.get("STEP"), Driver.QCHashMap.get("OS_BROWSER_VER"));
									Driver.QCHashMap.clear();
									Driver.QCHashMapTestId.clear();
									// removes each element from the list after each qc update starting from the first
									Driver.arlst.remove(0);
								}
							}
						}
					});
					thread.setDaemon(true);
					thread.start();

					// Checks for the skip size of the xls sheet 
					if(Driver.arlst.size() == 1){
						while(thread.isAlive()){
							System.out.println("waiting for QCThread to die");
							Thread.sleep(3000);
						}
					}
					if(Driver.arlst.size() == 0){
						Thread.currentThread().interrupt();
					}


				} catch (Exception e) {
					System.err.println(e);
					Thread.currentThread().interrupt();
				}

				System.out.println("AfterMethod end - " + driverType);
			}
		}
		catch(Exception e){
			System.out.println("exception " + Dictionary.get("TEST_NAME_"+ driverType) + driverType + ": " + e.toString());
		}

		//Quit Driver
		if(driver!=null){
			try{
				driver.quit();
			}catch(Exception e){
				//Do nothing
			}

		}
	}

	@AfterClass
	public void afterClass(){
		try{
			Reporter.fnCloseTestSummary();
		}catch(Exception e){
			System.out.println("exception " + Dictionary.get("TEST_NAME_"+ driverType) + driverType + ": " + e.toString());
		}
	}

}
